export interface CanvasLink {
  source: string;
  target: string;
}

export interface GraphLink {
  source: string;
  target: string;
}
