import React from 'react';
import { useSetAtom } from 'jotai';
import { CanvasNode } from '../../../CanvasNode';
import { getSlotColor } from '../../lib/styleUtils.ts';
import { lastExpandedIdAtom } from '../../../../store/atoms';

interface CodeCardSlotProps {
  tokenId: string;
  lineNum: number;
  slotIdx: number;
  depNode?: CanvasNode;
}

const CodeCardSlot: React.FC<CodeCardSlotProps> = ({ tokenId, lineNum, slotIdx, depNode }) => {
  const setLastExpandedId = useSetAtom(lastExpandedIdAtom);

  const slotColorClass = depNode
    ? getSlotColor(depNode.type)
    : 'bg-slate-500/60 border-slate-400/80 shadow-slate-500/30 group-hover/line:border-slate-300';

  const handleSlotClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Center camera on the target node
    setLastExpandedId(tokenId);
  };

  return (
    <div
      className={`w-2 h-2 rounded-full absolute -left-3.5 transition-all duration-300 border-2 group-hover/line:scale-110 shadow-lg cursor-pointer hover:scale-125 ${slotColorClass}`}
      style={{ top: `${6 + slotIdx * 0}px` }}
      data-input-slot-for={tokenId}
      data-input-slot-line={lineNum}
      data-input-slot-unique={`${tokenId}::line${lineNum}`}
      onClick={handleSlotClick}
    />
  );
};

export default CodeCardSlot;
